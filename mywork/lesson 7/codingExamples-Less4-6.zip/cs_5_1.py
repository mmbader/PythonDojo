def remove_head(p_list):
	del p_list[0]

t = ["a","b","c"]
print t[0]
remove_head(t)
print t[0]