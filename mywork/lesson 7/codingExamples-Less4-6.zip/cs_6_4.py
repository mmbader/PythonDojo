fpointer = open(raw_input("Filename: "), "w")
fpointer.write("Hello World!\n")
fpointer.close()
    